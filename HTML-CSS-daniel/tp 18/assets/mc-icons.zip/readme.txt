﻿=== Minecraft Icon Set ===

By: Kilo (http://www.rw-designer.com/user/87427) renatividal@yahoo.com

Download: http://www.rw-designer.com/icon-set/mc-icons

Author's description:

If you ever wanted some Minecraft icons. Well, you've found them! I took some images for Google and then converted them all into icons using the RW Icon Editor.

I will add more icons later.

The credit goes obviously to: Mojang.

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.